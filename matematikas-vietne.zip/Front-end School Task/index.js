$(".score-check").click(function(){
    let answer1 = $("#fraction").val();
    let answer2 = document.getElementById("second").checked;
    let answer3 = $("#sinus-q").val();
    let score = 0;
    if (answer1 == "0.1"){
        score++;
    }
    if (answer2){
        score++;
    }
    if (answer3 == "1"){
        score++;
    }
    $(".test-results").text(`Your score is ${score} out of 3`);
});